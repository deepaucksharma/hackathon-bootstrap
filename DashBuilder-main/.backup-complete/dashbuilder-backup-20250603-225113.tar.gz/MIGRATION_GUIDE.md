# DashBuilder Migration Guide

## Migrating from Legacy Scripts to DashBuilder 3.0

This guide helps you transition from the old script-based approach to the new unified DashBuilder.

## Quick Migration Reference

### Old Script → New Command Mapping

| Old Script | New Command | Notes |
|------------|-------------|-------|
| `scripts/create-kafka-dashboard.js` | `dashbuilder create kafka` | Uses Kafka template |
| `scripts/create-intelligent-kafka-dashboard.js` | `dashbuilder create kafka --intelligent` | Intelligent mode enabled by default |
| `scripts/discover-all-events.js` | `dashbuilder discover` | Comprehensive discovery |
| `scripts/quick-dashboard.js` | `dashbuilder create custom` | Custom dashboard without template |
| `scripts/validate-dashboard.js` | `dashbuilder validate <file>` | Validates dashboard JSON |
| `scripts/deploy-dashboard.js` | `dashbuilder deploy <file>` | Deploys to New Relic |
| Multiple discovery scripts | `dashbuilder discover --strategy <type>` | Unified discovery with strategies |

## Installation

```bash
# Remove old dependencies
rm -rf node_modules package-lock.json

# Use new package.json
mv package-new.json package.json

# Install unified dependencies
npm install

# Make CLI executable
chmod +x cli/dashbuilder.js

# Optional: Create global link
npm link
```

## Configuration

### Environment Variables (Same as before)
```bash
# .env file
NEW_RELIC_ACCOUNT_ID=your_account_id
NEW_RELIC_API_KEY=your_api_key
NEW_RELIC_REGION=US
```

### Programmatic Usage

Old way:
```javascript
// Multiple imports from different files
const createKafkaDashboard = require('./scripts/create-kafka-dashboard');
const discover = require('./scripts/discover-metrics');
const validator = require('./scripts/validate-dashboard');
```

New way:
```javascript
// Single import
const { createDashboardBuilder, discoverMetrics, createFromTemplate } = require('dashbuilder');

// Create dashboard
const builder = createDashboardBuilder(config);
const dashboard = await builder.build();

// Or use template
const kafkaDashboard = await createFromTemplate('kafka', config);
```

## Common Migration Scenarios

### 1. Creating a Kafka Dashboard

**Old way:**
```bash
node scripts/create-kafka-dashboard.js
node scripts/create-intelligent-kafka-dashboard.js
```

**New way:**
```bash
# Interactive mode
dashbuilder interactive

# Direct command
dashbuilder create kafka --name "Production Kafka" --deploy

# With custom options
dashbuilder create kafka --intelligent --output my-kafka-dash.json
```

### 2. Discovering Metrics

**Old way:**
```bash
node scripts/discover-all-events.js
node scripts/quick-discovery.js
node scripts/intelligent-discovery.js
```

**New way:**
```bash
# Intelligent discovery (default)
dashbuilder discover

# Comprehensive discovery
dashbuilder discover --strategy comprehensive

# Pattern-based discovery
dashbuilder discover --strategy pattern --patterns "kafka,broker,topic"

# Save results
dashbuilder discover --output metrics.json
```

### 3. Custom Dashboard Creation

**Old way:**
```javascript
// In scripts/create-custom-dashboard.js
const builder = new DashboardBuilder(config);
// ... lots of custom code ...
```

**New way:**
```javascript
// In your own script
const { createDashboardBuilder } = require('dashbuilder');

const builder = createDashboardBuilder({
  accountId: 12345,
  apiKey: 'your-key',
  intelligent: true
});

const dashboard = await builder.build({
  name: 'My Custom Dashboard',
  template: 'custom',
  // Your custom options
});
```

### 4. Validation and Deployment

**Old way:**
```bash
node scripts/validate-dashboard.js dashboard.json
node scripts/deploy-dashboard.js dashboard.json
```

**New way:**
```bash
# Validate
dashbuilder validate dashboard.json

# Deploy
dashbuilder deploy dashboard.json

# Validate and deploy in one step
dashbuilder create kafka --deploy
```

## API Changes

### DashboardBuilder Class

The new `DashboardBuilder` class consolidates functionality from multiple old builders:

```javascript
const builder = createDashboardBuilder(config);

// All these methods are now available on one instance:
await builder.build();              // Build dashboard
await builder.discover();           // Discover metrics  
await builder.validate(dashboard);  // Validate
await builder.deploy(dashboard);    // Deploy
await builder.export(dashboard, 'file.json'); // Export
```

### Templates

Templates are now first-class citizens:

```javascript
const { templates } = require('dashbuilder');

// List available templates
console.log(Object.keys(templates)); // ['kafka', 'system', 'custom']

// Use a template
const dashboard = await createFromTemplate('kafka', config);
```

## Cleanup

After migration, you can safely remove:

```bash
# Archive old scripts (optional)
mkdir legacy-scripts
mv scripts/*.js legacy-scripts/

# Remove old script directories
rm -rf scripts/src
rm -rf scripts/discovery-platform
rm -rf dashboard-generator

# Clean up duplicate package files
rm -rf scripts/package.json scripts/node_modules
rm -rf dashboard-generator/package.json dashboard-generator/node_modules

# Remove test output files
rm -f scripts/*.json
```

## Troubleshooting

### Issue: Command not found
```bash
# Make sure CLI is executable
chmod +x cli/dashbuilder.js

# Or use npm run
npm start -- create kafka
```

### Issue: Missing dependencies
```bash
# Clean install
rm -rf node_modules package-lock.json
npm install
```

### Issue: Old imports not working
Update your imports:
```javascript
// Old
const DashboardBuilder = require('./scripts/src/dashboard-builder');

// New
const { DashboardBuilder } = require('dashbuilder');
```

## Benefits of Migration

1. **Single CLI** - No more searching through 30+ scripts
2. **Consistent API** - One way to do things
3. **Better Performance** - Shared modules, caching, optimized code
4. **Cleaner Codebase** - 90% less code to maintain
5. **Better Documentation** - Centralized docs and help
6. **Future-Proof** - Easier to add new features

## Getting Help

```bash
# General help
dashbuilder --help

# Command-specific help
dashbuilder create --help
dashbuilder discover --help

# Interactive mode for guided experience
dashbuilder interactive
```

## Next Steps

1. Try the interactive mode: `dashbuilder interactive`
2. Create your first dashboard: `dashbuilder create kafka`
3. Explore templates: `dashbuilder list-templates`
4. Read the API docs in `docs/API.md`