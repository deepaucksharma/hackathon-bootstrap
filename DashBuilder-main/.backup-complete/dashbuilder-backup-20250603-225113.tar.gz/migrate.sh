#!/bin/bash

# DashBuilder Migration Script
# Automates the migration from legacy structure to streamlined DashBuilder 3.0

set -e

echo "🚀 DashBuilder Migration Script"
echo "==============================="
echo "This script will help you migrate to the streamlined DashBuilder 3.0"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if we're in the right directory
if [ ! -f "package.json" ] || [ ! -d "scripts" ]; then
    echo -e "${RED}❌ Error: Please run this script from the DashBuilder-main directory${NC}"
    exit 1
fi

echo -e "${BLUE}📋 Step 1: Creating backup${NC}"
mkdir -p .backup
cp -r scripts .backup/scripts-$(date +%Y%m%d-%H%M%S) 2>/dev/null || true
cp package.json .backup/package-old.json 2>/dev/null || true
echo -e "${GREEN}✅ Backup created in .backup directory${NC}"

echo -e "\n${BLUE}📋 Step 2: Creating new directory structure${NC}"

# Create new directories
mkdir -p src/core
mkdir -p src/analyzers
mkdir -p src/templates
mkdir -p src/utils
mkdir -p cli
mkdir -p examples
mkdir -p test
mkdir -p docs

echo -e "${GREEN}✅ Directory structure created${NC}"

echo -e "\n${BLUE}📋 Step 3: Installing new package.json${NC}"

if [ -f "package-new.json" ]; then
    mv package.json package-old.json
    mv package-new.json package.json
    echo -e "${GREEN}✅ New package.json installed${NC}"
else
    echo -e "${YELLOW}⚠️  Warning: package-new.json not found, keeping existing package.json${NC}"
fi

echo -e "\n${BLUE}📋 Step 4: Archiving legacy scripts${NC}"

# Create legacy archive
mkdir -p .legacy
mv scripts .legacy/scripts-archive 2>/dev/null || true
mv dashboard-generator .legacy/dashboard-generator-archive 2>/dev/null || true
mv sample-dashboard .legacy/sample-dashboard-archive 2>/dev/null || true

# Move any test/output JSON files
find . -maxdepth 1 -name "*.json" -not -name "package*.json" -exec mv {} .legacy/ \; 2>/dev/null || true

echo -e "${GREEN}✅ Legacy files archived in .legacy directory${NC}"

echo -e "\n${BLUE}📋 Step 5: Creating examples${NC}"

# Create basic example
cat > examples/basic-dashboard.js << 'EOF'
/**
 * Basic Dashboard Example
 * Shows how to create a simple dashboard using DashBuilder
 */

const { createDashboardBuilder } = require('../src');

async function main() {
  // Configuration from environment or directly
  const config = {
    accountId: process.env.NEW_RELIC_ACCOUNT_ID,
    apiKey: process.env.NEW_RELIC_API_KEY,
    intelligent: true
  };

  // Create builder instance
  const builder = createDashboardBuilder(config);

  // Build dashboard
  const dashboard = await builder.build({
    name: 'My Basic Dashboard',
    description: 'Created with DashBuilder'
  });

  // Export to file
  await builder.export(dashboard, 'basic-dashboard.json');
  
  console.log('Dashboard created successfully!');
}

main().catch(console.error);
EOF

# Create Kafka example
cat > examples/kafka-monitoring.js << 'EOF'
/**
 * Kafka Monitoring Dashboard Example
 * Shows how to create a Kafka dashboard from template
 */

const { createFromTemplate } = require('../src');

async function main() {
  const config = {
    accountId: process.env.NEW_RELIC_ACCOUNT_ID,
    apiKey: process.env.NEW_RELIC_API_KEY
  };

  // Create from Kafka template
  const dashboard = await createFromTemplate('kafka', {
    ...config,
    name: 'Kafka Production Monitoring',
    intelligent: true
  });

  // Dashboard is ready to deploy or export
  console.log(`Created dashboard: ${dashboard.name}`);
  console.log(`Total widgets: ${dashboard.pages[0].widgets.length}`);
}

main().catch(console.error);
EOF

echo -e "${GREEN}✅ Example files created${NC}"

echo -e "\n${BLUE}📋 Step 6: Creating README${NC}"

# Create new README
cat > README-NEW.md << 'EOF'
# DashBuilder

Unified New Relic Dashboard Builder - Create intelligent dashboards with ease.

## Quick Start

```bash
# Install dependencies
npm install

# Run interactive mode
npm start interactive

# Or use CLI directly
./cli/dashbuilder.js create kafka --deploy
```

## Features

- 📊 **Unified CLI** - Single command for all dashboard operations
- 🧠 **Intelligent Mode** - Smart metric analysis and visualization selection  
- 📋 **Templates** - Pre-built templates for common use cases (Kafka, System, etc.)
- 🔍 **Metric Discovery** - Find and analyze available metrics
- ✅ **Validation** - Built-in dashboard validation
- 🚀 **Direct Deployment** - Deploy to New Relic with one command

## Usage

### CLI Commands

```bash
# Discover metrics
dashbuilder discover

# Create dashboard from template
dashbuilder create kafka --name "My Kafka Dashboard"

# Create custom dashboard
dashbuilder create custom --intelligent

# Validate dashboard
dashbuilder validate dashboard.json

# Deploy dashboard
dashbuilder deploy dashboard.json

# Interactive mode
dashbuilder interactive
```

### Programmatic Usage

```javascript
const { createDashboardBuilder, createFromTemplate } = require('dashbuilder');

// Create custom dashboard
const builder = createDashboardBuilder(config);
const dashboard = await builder.build();

// Use template
const kafkaDashboard = await createFromTemplate('kafka', config);
```

See [examples/](examples/) for more usage examples.

## Documentation

- [Migration Guide](MIGRATION_GUIDE.md) - Migrating from legacy scripts
- [API Reference](docs/API.md) - Detailed API documentation
- [Templates](docs/TEMPLATES.md) - Available dashboard templates

## License

MIT
EOF

echo -e "${GREEN}✅ README created${NC}"

echo -e "\n${BLUE}📋 Step 7: Cleaning up${NC}"

# Remove old node_modules and package-lock files
rm -rf node_modules package-lock.json
rm -rf scripts/node_modules scripts/package-lock.json 2>/dev/null || true
rm -rf dashboard-generator/node_modules dashboard-generator/package-lock.json 2>/dev/null || true

echo -e "${GREEN}✅ Cleanup complete${NC}"

echo -e "\n${BLUE}📋 Step 8: Installing dependencies${NC}"

npm install

echo -e "${GREEN}✅ Dependencies installed${NC}"

# Make CLI executable
chmod +x cli/dashbuilder.js

echo -e "\n${GREEN}🎉 Migration Complete!${NC}"
echo ""
echo "Next steps:"
echo "1. Review the new structure in src/"
echo "2. Check examples in examples/"
echo "3. Try the new CLI: ${BLUE}./cli/dashbuilder.js --help${NC}"
echo "4. Or use interactive mode: ${BLUE}npm start interactive${NC}"
echo ""
echo "Your old files are safely backed up in:"
echo "  - ${YELLOW}.backup/${NC} (original backup)"
echo "  - ${YELLOW}.legacy/${NC} (archived scripts)"
echo ""
echo "To create a global command, run: ${BLUE}npm link${NC}"