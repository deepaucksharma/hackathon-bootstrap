# DashBuilder Streamlining Plan V2

## Current State Issues

1. **Massive Script Duplication**: 30+ dashboard creation scripts with overlapping functionality
2. **Multiple Discovery Implementations**: 10+ discovery scripts doing similar things
3. **Scattered Components**: Logic spread across scripts/, dashboard-generator/, and src/
4. **No Clear Entry Point**: Unclear which script to use for what purpose
5. **Test Files Mixed with Production**: Test results and production code intermixed

## Proposed Streamlined Structure

```
DashBuilder/
├── src/                        # Core library (single source of truth)
│   ├── index.js               # Main entry point
│   ├── core/                  # Core components
│   │   ├── DashboardBuilder.js
│   │   ├── MetricDiscovery.js
│   │   ├── QueryBuilder.js
│   │   └── LayoutOptimizer.js
│   ├── analyzers/             # Analysis components
│   │   ├── MetricAnalyzer.js
│   │   └── IntelligentAnalyzer.js
│   ├── templates/             # Dashboard templates
│   │   ├── kafka.js
│   │   ├── system.js
│   │   └── custom.js
│   └── utils/                 # Utilities
│       ├── nerdgraph.js
│       ├── validators.js
│       └── logger.js
├── cli/                       # CLI interface
│   └── dashbuilder.js        # Single CLI entry point
├── examples/                  # Example usage
│   ├── basic-dashboard.js
│   ├── kafka-monitoring.js
│   └── README.md
├── test/                      # All tests
│   └── *.test.js
├── docs/                      # Documentation
│   ├── README.md
│   ├── API.md
│   └── GUIDES.md
├── package.json              # Single package.json
├── .gitignore
└── README.md

```

## Consolidation Actions

### Phase 1: Core Library Creation
1. **Merge Dashboard Builders** (30+ files → 1 file)
   - Combine best features from all dashboard creation scripts
   - Create single `DashboardBuilder` class with all capabilities
   - Support templates, intelligent mode, and custom configurations

2. **Unify Discovery** (10+ files → 1 file)
   - Merge all discovery implementations into `MetricDiscovery`
   - Support multiple discovery strategies
   - Cache results to avoid redundant API calls

3. **Consolidate Analyzers** (5+ files → 2 files)
   - Basic `MetricAnalyzer` for standard analysis
   - `IntelligentAnalyzer` for advanced features

### Phase 2: CLI Simplification
Create single CLI with clear commands:
```bash
dashbuilder discover              # Discover metrics
dashbuilder create kafka          # Create Kafka dashboard
dashbuilder create custom         # Create custom dashboard
dashbuilder validate <file>       # Validate dashboard
dashbuilder deploy <file>         # Deploy dashboard
```

### Phase 3: Cleanup
1. **Remove Redundant Scripts**:
   - Delete 30+ individual dashboard scripts
   - Remove duplicate discovery implementations
   - Clean up test output files

2. **Organize Remaining Code**:
   - Move reusable components to src/
   - Archive old scripts to `legacy/` temporarily
   - Update imports and dependencies

### Phase 4: Documentation
1. Create clear README with:
   - Getting started guide
   - API documentation
   - Migration guide from old scripts

## Benefits

1. **90% Code Reduction**: From 50+ scripts to ~10 core files
2. **Clear API**: Single entry point with consistent interface
3. **Maintainability**: Easier to update and extend
4. **Performance**: Reduced redundancy and better caching
5. **Usability**: Clear documentation and examples

## Migration Path

For users of existing scripts:
```javascript
// Old way (multiple scripts)
node scripts/create-kafka-dashboard.js
node scripts/intelligent-dashboard-builder.js

// New way (unified CLI)
dashbuilder create kafka --intelligent
dashbuilder create custom --template system
```

## Implementation Timeline

- Phase 1: 3-4 hours (Core library)
- Phase 2: 1-2 hours (CLI)
- Phase 3: 1-2 hours (Cleanup)
- Phase 4: 1 hour (Documentation)

Total: ~8 hours for complete streamlining