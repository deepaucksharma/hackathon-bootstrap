#!/usr/bin/env node

/**
 * DashBuilder CLI - Unified command-line interface
 * 
 * Replaces 30+ individual scripts with a single, powerful CLI
 */

const { program } = require('commander');
const chalk = require('chalk');
const ora = require('ora');
const inquirer = require('inquirer');
const fs = require('fs').promises;
const path = require('path');
require('dotenv').config();

const { 
  createDashboardBuilder,
  discoverMetrics,
  createFromTemplate,
  templates
} = require('../src');

// Version from package.json
const { version } = require('../package.json');

// Configure CLI
program
  .name('dashbuilder')
  .description('Unified New Relic Dashboard Builder')
  .version(version);

/**
 * Discover command - find available metrics
 */
program
  .command('discover')
  .description('Discover available metrics in your New Relic account')
  .option('-s, --strategy <type>', 'Discovery strategy (comprehensive|intelligent|pattern|quick)', 'intelligent')
  .option('-p, --patterns <patterns>', 'Comma-separated patterns to match', '')
  .option('-o, --output <file>', 'Save results to file')
  .option('--no-cache', 'Disable caching')
  .action(async (options) => {
    const spinner = ora('Discovering metrics...').start();
    
    try {
      const config = await getConfig();
      const discoveryOptions = {
        strategy: options.strategy,
        useCache: options.cache
      };
      
      if (options.patterns) {
        discoveryOptions.patterns = createPatternsFromString(options.patterns);
      }
      
      const results = await discoverMetrics({ ...config, ...discoveryOptions });
      
      spinner.succeed(`Discovered ${results.totalMetrics} metrics across ${results.eventTypes.length} event types`);
      
      // Display summary
      console.log('\n' + chalk.bold('Summary:'));
      console.log(chalk.gray('─'.repeat(50)));
      console.log(`Total Event Types: ${chalk.cyan(results.summary.totalEventTypes)}`);
      console.log(`Total Metrics: ${chalk.cyan(results.summary.totalMetrics)}`);
      
      if (results.summary.topEventTypes) {
        console.log('\n' + chalk.bold('Top Event Types:'));
        results.summary.topEventTypes.forEach(et => {
          console.log(`  ${chalk.green(et.eventType)}: ${et.metricCount} metrics`);
        });
      }
      
      // Save to file if requested
      if (options.output) {
        await fs.writeFile(options.output, JSON.stringify(results, null, 2));
        console.log(`\n✅ Results saved to ${chalk.yellow(options.output)}`);
      }
      
    } catch (error) {
      spinner.fail('Discovery failed');
      console.error(chalk.red(error.message));
      process.exit(1);
    }
  });

/**
 * Create command - build a dashboard
 */
program
  .command('create [template]')
  .description('Create a new dashboard')
  .option('-n, --name <name>', 'Dashboard name')
  .option('-i, --intelligent', 'Use intelligent mode', true)
  .option('-o, --output <file>', 'Save dashboard to file')
  .option('-d, --deploy', 'Deploy to New Relic after creation')
  .action(async (template, options) => {
    try {
      const config = await getConfig();
      
      // If template not provided, show selection
      if (!template) {
        const answers = await inquirer.prompt([{
          type: 'list',
          name: 'template',
          message: 'Select a template:',
          choices: [
            ...Object.keys(templates),
            { name: 'Custom (no template)', value: 'custom' }
          ]
        }]);
        template = answers.template;
      }
      
      // Get dashboard name if not provided
      if (!options.name) {
        const answers = await inquirer.prompt([{
          type: 'input',
          name: 'name',
          message: 'Dashboard name:',
          default: `${template} Dashboard - ${new Date().toLocaleDateString()}`
        }]);
        options.name = answers.name;
      }
      
      const spinner = ora('Creating dashboard...').start();
      
      let dashboard;
      
      if (template === 'custom') {
        // Create custom dashboard
        const builder = createDashboardBuilder({
          ...config,
          intelligent: options.intelligent,
          name: options.name
        });
        
        dashboard = await builder.build();
      } else {
        // Create from template
        dashboard = await createFromTemplate(template, {
          ...config,
          intelligent: options.intelligent,
          name: options.name
        });
      }
      
      spinner.succeed('Dashboard created successfully');
      
      // Save to file
      const outputFile = options.output || `${template}-dashboard-${Date.now()}.json`;
      await fs.writeFile(outputFile, JSON.stringify(dashboard, null, 2));
      console.log(`\n✅ Dashboard saved to ${chalk.yellow(outputFile)}`);
      
      // Deploy if requested
      if (options.deploy) {
        const deploySpinner = ora('Deploying to New Relic...').start();
        try {
          const builder = createDashboardBuilder(config);
          const result = await builder.deploy(dashboard);
          deploySpinner.succeed(`Dashboard deployed successfully! GUID: ${chalk.cyan(result.guid)}`);
        } catch (error) {
          deploySpinner.fail('Deployment failed');
          console.error(chalk.red(error.message));
        }
      }
      
    } catch (error) {
      console.error(chalk.red('Dashboard creation failed:'), error.message);
      process.exit(1);
    }
  });

/**
 * Validate command - check dashboard structure
 */
program
  .command('validate <file>')
  .description('Validate a dashboard JSON file')
  .action(async (file) => {
    try {
      const content = await fs.readFile(file, 'utf8');
      const dashboard = JSON.parse(content);
      
      const { validators } = require('../src').utils;
      const validation = validators.validateDashboard(dashboard);
      
      if (validation.valid) {
        console.log(chalk.green('✅ Dashboard is valid!'));
        
        // Show dashboard info
        console.log('\n' + chalk.bold('Dashboard Info:'));
        console.log(chalk.gray('─'.repeat(50)));
        console.log(`Name: ${chalk.cyan(dashboard.name)}`);
        console.log(`Pages: ${chalk.cyan(dashboard.pages.length)}`);
        console.log(`Total Widgets: ${chalk.cyan(dashboard.pages.reduce((sum, p) => sum + p.widgets.length, 0))}`);
      } else {
        console.log(chalk.red('❌ Dashboard validation failed:'));
        validation.errors.forEach(error => {
          console.log(`  - ${error}`);
        });
        process.exit(1);
      }
      
    } catch (error) {
      console.error(chalk.red('Validation error:'), error.message);
      process.exit(1);
    }
  });

/**
 * Deploy command - deploy dashboard to New Relic
 */
program
  .command('deploy <file>')
  .description('Deploy a dashboard to New Relic')
  .action(async (file) => {
    const spinner = ora('Deploying dashboard...').start();
    
    try {
      const config = await getConfig();
      const content = await fs.readFile(file, 'utf8');
      const dashboard = JSON.parse(content);
      
      const builder = createDashboardBuilder(config);
      const result = await builder.deploy(dashboard);
      
      spinner.succeed(`Dashboard deployed successfully!`);
      console.log(`\n🎉 Dashboard GUID: ${chalk.cyan(result.guid)}`);
      console.log(`📊 View at: ${chalk.blue(`https://one.newrelic.com/dashboards/${result.guid}`)}`);
      
    } catch (error) {
      spinner.fail('Deployment failed');
      console.error(chalk.red(error.message));
      process.exit(1);
    }
  });

/**
 * List command - show available templates
 */
program
  .command('list-templates')
  .description('List available dashboard templates')
  .action(() => {
    console.log(chalk.bold('\nAvailable Templates:'));
    console.log(chalk.gray('─'.repeat(50)));
    
    Object.entries(templates).forEach(([name, template]) => {
      console.log(`\n${chalk.green(name)}:`);
      console.log(`  ${template.description || 'No description available'}`);
      if (template.features) {
        console.log(`  Features: ${template.features.join(', ')}`);
      }
    });
  });

/**
 * Interactive mode - guided dashboard creation
 */
program
  .command('interactive')
  .description('Interactive dashboard creation wizard')
  .action(async () => {
    console.log(chalk.bold('\n🚀 Welcome to DashBuilder Interactive Mode!\n'));
    
    try {
      // Get configuration
      const config = await getConfig();
      
      // Ask questions
      const answers = await inquirer.prompt([
        {
          type: 'list',
          name: 'action',
          message: 'What would you like to do?',
          choices: [
            'Create a dashboard from template',
            'Create a custom dashboard',
            'Discover available metrics',
            'Validate an existing dashboard'
          ]
        },
        {
          type: 'list',
          name: 'template',
          message: 'Select a template:',
          choices: Object.keys(templates),
          when: (ans) => ans.action === 'Create a dashboard from template'
        },
        {
          type: 'input',
          name: 'name',
          message: 'Dashboard name:',
          default: (ans) => `${ans.template || 'Custom'} Dashboard - ${new Date().toLocaleDateString()}`,
          when: (ans) => ans.action.includes('Create')
        },
        {
          type: 'confirm',
          name: 'intelligent',
          message: 'Use intelligent mode?',
          default: true,
          when: (ans) => ans.action.includes('Create')
        },
        {
          type: 'confirm',
          name: 'deploy',
          message: 'Deploy to New Relic after creation?',
          default: false,
          when: (ans) => ans.action.includes('Create')
        }
      ]);
      
      // Execute based on answers
      if (answers.action === 'Discover available metrics') {
        await program.parseAsync(['node', 'dashbuilder', 'discover'], { from: 'user' });
      } else if (answers.action.includes('Create')) {
        const options = {
          name: answers.name,
          intelligent: answers.intelligent,
          deploy: answers.deploy
        };
        
        if (answers.template) {
          await program.parseAsync(['node', 'dashbuilder', 'create', answers.template, ...buildOptionsArray(options)], { from: 'user' });
        } else {
          await program.parseAsync(['node', 'dashbuilder', 'create', 'custom', ...buildOptionsArray(options)], { from: 'user' });
        }
      }
      
    } catch (error) {
      console.error(chalk.red('Interactive mode error:'), error.message);
      process.exit(1);
    }
  });

// Helper functions

/**
 * Get configuration from environment or prompt
 */
async function getConfig() {
  const config = {
    accountId: process.env.NEW_RELIC_ACCOUNT_ID,
    apiKey: process.env.NEW_RELIC_API_KEY || process.env.NEW_RELIC_USER_KEY,
    region: process.env.NEW_RELIC_REGION || 'US'
  };
  
  // Check if config is complete
  if (!config.accountId || !config.apiKey) {
    console.log(chalk.yellow('\n⚠️  Missing configuration. Please provide:'));
    
    const answers = await inquirer.prompt([
      {
        type: 'input',
        name: 'accountId',
        message: 'New Relic Account ID:',
        when: !config.accountId,
        validate: (input) => /^\d+$/.test(input) || 'Please enter a valid account ID'
      },
      {
        type: 'password',
        name: 'apiKey',
        message: 'New Relic API Key:',
        when: !config.apiKey,
        validate: (input) => input.length > 0 || 'API key is required'
      }
    ]);
    
    Object.assign(config, answers);
  }
  
  return config;
}

/**
 * Create pattern objects from comma-separated string
 */
function createPatternsFromString(patternsStr) {
  const patterns = {};
  patternsStr.split(',').forEach((pattern, index) => {
    patterns[`pattern${index}`] = new RegExp(pattern.trim(), 'i');
  });
  return patterns;
}

/**
 * Build options array for parseAsync
 */
function buildOptionsArray(options) {
  const args = [];
  
  if (options.name) {
    args.push('--name', options.name);
  }
  if (options.intelligent) {
    args.push('--intelligent');
  }
  if (options.deploy) {
    args.push('--deploy');
  }
  
  return args;
}

// Parse command line arguments
program.parse(process.argv);

// Show help if no command provided
if (!process.argv.slice(2).length) {
  program.outputHelp();
}