#!/usr/bin/env node

/**
 * Check what data is available in the account
 */

const dotenv = require('dotenv');
const path = require('path');
const chalk = require('chalk');

// Load environment variables
dotenv.config({ path: path.join(__dirname, '..', '.env') });

const { NerdGraphClient } = require('./src/core/api-client');

async function checkAccountData() {
  console.log(chalk.bold.blue('\n🔍 Checking Account Data\n'));
  
  const config = {
    accountId: process.env.ACC || process.env.NEW_RELIC_ACCOUNT_ID,
    apiKey: process.env.UKEY || process.env.NEW_RELIC_API_KEY
  };
  
  console.log(chalk.gray(`Account: ${config.accountId}`));
  
  const client = new NerdGraphClient({
    apiKey: config.apiKey,
    region: 'US'
  });
  
  try {
    // Check for any event types
    console.log(chalk.yellow('\nChecking event types...'));
    
    const eventQuery = `
      SELECT count(*) 
      FROM Transaction, SystemSample, KafkaBrokerSample, NetworkSample, ProcessSample, Metric
      FACET eventType()
      SINCE 1 hour ago
    `;
    
    const result = await client.nrql(config.accountId, eventQuery);
    
    if (result?.results) {
      console.log(chalk.white('\n📊 Available Event Types:'));
      result.results.forEach(r => {
        if (r.count > 0) {
          console.log(chalk.gray(`  • ${r.facet[0]}: ${r.count} events`));
        }
      });
    }
    
    // Check for metrics
    console.log(chalk.yellow('\nChecking metrics...'));
    
    const metricsQuery = `
      SELECT uniques(metricName, 20) 
      FROM Metric 
      SINCE 1 hour ago
    `;
    
    const metricsResult = await client.nrql(config.accountId, metricsQuery);
    
    if (metricsResult?.results?.[0]) {
      const metrics = metricsResult.results[0]['uniques.metricName'] || [];
      console.log(chalk.white(`\n📊 Found ${metrics.length} metrics`));
      if (metrics.length > 0) {
        console.log(chalk.gray('Sample metrics:'));
        metrics.slice(0, 10).forEach(m => {
          console.log(chalk.gray(`  • ${m}`));
        });
      }
    }
    
  } catch (error) {
    console.error(chalk.red('Error:'), error.message);
  }
}

checkAccountData().catch(console.error);