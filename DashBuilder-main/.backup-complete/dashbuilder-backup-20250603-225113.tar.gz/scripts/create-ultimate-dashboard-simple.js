#!/usr/bin/env node

/**
 * Create Ultimate Dashboard - Simplified Version
 * Focuses on discovered Kafka data with intelligent features
 */

const dotenv = require('dotenv');
const path = require('path');
const chalk = require('chalk');
const ora = require('ora');
const fs = require('fs');

// Load environment variables
dotenv.config({ path: path.join(__dirname, '..', '.env') });

const { NerdGraphClient } = require('./src/core/api-client');
const IntelligentDashboardBuilder = require('./discovery-platform/lib/intelligent-dashboard-builder');

async function createUltimateDashboard() {
  console.log(chalk.bold.blue('\n🚀 Creating Ultimate Kafka Intelligent Dashboard\n'));
  
  const config = {
    accountId: process.env.ACC || process.env.NEW_RELIC_ACCOUNT_ID,
    apiKey: process.env.UKEY || process.env.NEW_RELIC_API_KEY,
    enableAnomalyDetection: true,
    enableCorrelations: true,
    enablePredictions: true
  };
  
  if (!config.accountId || !config.apiKey) {
    console.error(chalk.red('Missing account ID or API key'));
    process.exit(1);
  }
  
  console.log(chalk.gray(`Account: ${config.accountId}`));
  
  const client = new NerdGraphClient({
    apiKey: config.apiKey,
    region: 'US'
  });
  
  const spinner = ora('Discovering Kafka infrastructure...').start();
  
  try {
    // Phase 1: Focused Kafka Discovery
    const kafkaEventTypes = [
      'KafkaBrokerSample',
      'KafkaTopicSample', 
      'KafkaConsumerSample',
      'KafkaProducerSample',
      'KafkaOffsetSample'
    ];
    
    const infraEventTypes = [
      'SystemSample',
      'NetworkSample',
      'StorageSample',
      'ProcessSample',
      'ContainerSample'
    ];
    
    const allEventTypes = [...kafkaEventTypes, ...infraEventTypes];
    const discoveredEventTypes = [];
    
    // Check each event type
    for (const eventType of allEventTypes) {
      try {
        const checkQuery = `SELECT count(*) FROM ${eventType} SINCE 1 hour ago`;
        const result = await client.nrql(config.accountId, checkQuery);
        
        if (result?.results?.[0]?.count > 0) {
          spinner.text = `Found ${eventType}: ${result.results[0].count} events`;
          
          // Get attributes
          const attrQuery = `SELECT keyset() FROM ${eventType} LIMIT 1 SINCE 1 hour ago`;
          const attrResult = await client.nrql(config.accountId, attrQuery);
          const attributes = attrResult?.results?.[0]?.['keyset()'] || [];
          
          // Get sample
          const sampleQuery = `SELECT * FROM ${eventType} LIMIT 1 SINCE 1 hour ago`;
          const sampleResult = await client.nrql(config.accountId, sampleQuery);
          const sample = sampleResult?.results?.[0] || {};
          
          // Build typed attributes
          const typedAttributes = attributes
            .filter(attr => !['timestamp', 'eventType'].includes(attr))
            .slice(0, 50) // Limit to prevent overwhelming
            .map(attr => ({
              name: attr,
              type: typeof sample[attr]
            }));
          
          discoveredEventTypes.push({
            name: eventType,
            count: result.results[0].count,
            volume: result.results[0].count,
            attributes: typedAttributes
          });
        }
      } catch (error) {
        // Skip if event type doesn't exist
      }
    }
    
    spinner.succeed(`Discovered ${discoveredEventTypes.length} event types`);
    
    // Phase 2: Discover Kafka Metrics
    spinner.start('Discovering Kafka metrics...');
    
    const metricsQuery = `
      SELECT uniques(metricName, 500) 
      FROM Metric 
      WHERE metricName LIKE '%kafka%' 
         OR metricName LIKE '%broker%'
         OR metricName LIKE '%topic%'
         OR metricName LIKE '%consumer%'
         OR metricName LIKE '%producer%'
         OR metricName LIKE '%newrelic.goldenmetrics.infra.kafka%'
      SINCE 1 hour ago
    `;
    
    const metricsResult = await client.nrql(config.accountId, metricsQuery);
    const kafkaMetrics = metricsResult?.results?.[0]?.['uniques.metricName'] || [];
    
    spinner.succeed(`Discovered ${kafkaMetrics.length} Kafka metrics`);
    
    // Display discovery summary
    console.log(chalk.white('\n📊 Discovery Summary:'));
    console.log(chalk.gray(`  • Event Types: ${discoveredEventTypes.length}`));
    discoveredEventTypes.forEach(et => {
      const icon = et.name.includes('Kafka') ? '🔥' : '💻';
      console.log(chalk.gray(`    ${icon} ${et.name}: ${et.count.toLocaleString()} events, ${et.attributes.length} attributes`));
    });
    console.log(chalk.gray(`  • Kafka Metrics: ${kafkaMetrics.length}`));
    
    // Phase 3: Build Discovery Results
    const discoveryResults = {
      timestamp: new Date().toISOString(),
      accountId: config.accountId,
      eventTypes: discoveredEventTypes,
      metrics: kafkaMetrics.map(name => ({
        name,
        type: 'metric',
        unit: guessMetricUnit(name)
      })),
      relationships: []
    };
    
    // Add relationships
    const hasKafka = discoveredEventTypes.find(et => et.name === 'KafkaBrokerSample');
    const hasSystem = discoveredEventTypes.find(et => et.name === 'SystemSample');
    
    if (hasKafka && hasSystem) {
      discoveryResults.relationships.push({
        from: 'KafkaBrokerSample',
        to: 'SystemSample',
        type: 'runs_on'
      });
    }
    
    // Save discovery
    const discoveryFile = path.join(__dirname, `ultimate-kafka-discovery-${Date.now()}.json`);
    fs.writeFileSync(discoveryFile, JSON.stringify(discoveryResults, null, 2));
    console.log(chalk.gray(`\n💾 Discovery saved to: ${discoveryFile}`));
    
    // Phase 4: Build Ultimate Dashboard
    console.log(chalk.yellow('\n🧠 Building Ultimate Intelligent Dashboard...\n'));
    
    const builder = new IntelligentDashboardBuilder(config);
    
    // Build dashboard
    spinner.start('Generating intelligent dashboard...');
    const dashboardResult = await builder.buildDashboards(discoveryResults);
    spinner.succeed('Dashboard generated successfully');
    
    // Display results
    console.log(chalk.bold.green('\n✅ Ultimate Dashboard Created!\n'));
    
    // Show categorization
    console.log(chalk.white('📊 Intelligent Metric Categorization:'));
    let totalCategorized = 0;
    const categoryBreakdown = {};
    
    for (const [category, metrics] of Object.entries(dashboardResult.analysis.categories)) {
      if (metrics.length > 0) {
        const icon = builder.getCategoryIcon(category);
        const name = builder.formatCategoryName(category);
        console.log(chalk.gray(`  ${icon} ${name}: ${metrics.length} metrics`));
        totalCategorized += metrics.length;
        categoryBreakdown[category] = metrics.length;
      }
    }
    
    // Show golden signals
    console.log(chalk.white('\n🚦 Golden Signals Mapping:'));
    let totalGoldenSignals = 0;
    for (const [signal, metrics] of Object.entries(dashboardResult.analysis.goldenSignals)) {
      if (metrics.length > 0) {
        console.log(chalk.gray(`  • ${signal}: ${metrics.length} metrics`));
        totalGoldenSignals += metrics.length;
      }
    }
    
    // Show correlations
    if (dashboardResult.correlations.strong.length > 0) {
      console.log(chalk.white('\n🔗 Detected Correlations:'));
      dashboardResult.correlations.strong.slice(0, 5).forEach(corr => {
        console.log(chalk.gray(`  • ${corr.metric1} ↔ ${corr.metric2} (${corr.type})`));
      });
      if (dashboardResult.correlations.strong.length > 5) {
        console.log(chalk.gray(`  ... and ${dashboardResult.correlations.strong.length - 5} more`));
      }
    }
    
    // Show insights
    if (dashboardResult.insights.length > 0) {
      console.log(chalk.white('\n💡 Intelligent Insights:'));
      dashboardResult.insights.forEach(insight => {
        const icon = insight.severity === 'high' ? '🔴' : 
                    insight.severity === 'medium' ? '🟡' : '🟢';
        console.log(chalk.gray(`  ${icon} ${insight.message}`));
      });
    }
    
    // Dashboard details
    console.log(chalk.white('\n📈 Dashboard Information:'));
    console.log(chalk.gray(`  • Name: ${dashboardResult.dashboard.name}`));
    console.log(chalk.gray(`  • GUID: ${dashboardResult.dashboard.guid}`));
    console.log(chalk.gray(`  • URL: ${dashboardResult.dashboard.url}`));
    
    // Verify dynamic catalog
    const dashboardConfig = builder.buildDashboardConfig(
      await builder.createOptimizedWidgets(
        builder.generateDashboardPlan(dashboardResult.analysis, dashboardResult.correlations),
        dashboardResult.analysis
      ),
      dashboardResult.analysis
    );
    
    const catalogPage = dashboardConfig.pages.find(p => p.name === 'All Metrics Catalog');
    
    console.log(chalk.white('\n✨ Dashboard Features:'));
    console.log(chalk.gray(`  ✅ ${dashboardConfig.pages.length} intelligent pages`));
    console.log(chalk.gray(`  ✅ ${totalCategorized} metrics categorized`));
    console.log(chalk.gray(`  ✅ ${totalGoldenSignals} golden signal mappings`));
    console.log(chalk.gray(`  ✅ ${dashboardResult.correlations.strong.length} correlations detected`));
    console.log(chalk.gray(`  ✅ ${catalogPage ? 'Dynamic metrics catalog' : 'No catalog'}`));
    console.log(chalk.gray(`  ✅ Optimal visualizations selected`));
    console.log(chalk.gray(`  ✅ Anomaly detection enabled`));
    console.log(chalk.gray(`  ✅ Predictive insights generated`));
    
    // List pages
    console.log(chalk.white('\n📄 Dashboard Pages:'));
    dashboardConfig.pages.forEach((page, idx) => {
      console.log(chalk.gray(`  ${idx + 1}. ${page.name} (${page.widgets.length} widgets)`));
    });
    
    // Save complete results
    const outputFile = path.join(__dirname, `ultimate-dashboard-results-${Date.now()}.json`);
    fs.writeFileSync(outputFile, JSON.stringify({
      config: { accountId: config.accountId },
      discovery: {
        eventTypes: discoveredEventTypes.map(et => ({
          name: et.name,
          count: et.count,
          attributes: et.attributes.length
        })),
        metrics: kafkaMetrics.length
      },
      categorization: categoryBreakdown,
      analysis: dashboardResult.analysis,
      correlations: dashboardResult.correlations,
      insights: dashboardResult.insights,
      dashboard: dashboardResult.dashboard,
      pages: dashboardConfig.pages.map(p => ({
        name: p.name,
        widgets: p.widgets.length
      }))
    }, null, 2));
    
    console.log(chalk.gray(`\n💾 Results saved to: ${outputFile}`));
    
    console.log(chalk.bold.cyan('\n🎉 Your Ultimate Intelligent Kafka Dashboard is ready!\n'));
    
  } catch (error) {
    spinner.fail('Dashboard creation failed');
    console.error(chalk.red('\n❌ Error:'), error.message);
    
    if (error.stack) {
      console.error(chalk.gray('\nStack trace:'));
      console.error(chalk.gray(error.stack));
    }
    
    process.exit(1);
  }
}

function guessMetricUnit(metricName) {
  const name = metricName.toLowerCase();
  
  if (name.includes('persecond') || name.includes('rate')) return 'per_second';
  if (name.includes('percent') || name.includes('percentage')) return 'percent';
  if (name.includes('bytes')) return 'bytes';
  if (name.includes('milliseconds') || name.includes('ms')) return 'milliseconds';
  if (name.includes('seconds') || name.includes('sec')) return 'seconds';
  if (name.includes('count') || name.includes('total')) return 'count';
  if (name.includes('lag')) return 'count';
  if (name.includes('size')) return 'bytes';
  
  return 'unknown';
}

// Run the ultimate dashboard creation
createUltimateDashboard().catch(console.error);