#!/usr/bin/env node

/**
 * Create Ultimate Intelligent Dashboard
 * Runs full discovery and builds comprehensive dashboard with all features
 */

const dotenv = require('dotenv');
const path = require('path');
const chalk = require('chalk');
const ora = require('ora');
const fs = require('fs');

// Load environment variables
dotenv.config({ path: path.join(__dirname, '..', '.env') });

const { NerdGraphClient } = require('./src/core/api-client');
const IntelligentDashboardBuilder = require('./discovery-platform/lib/intelligent-dashboard-builder');
const AdvancedMetricAnalyzer = require('./discovery-platform/lib/advanced-metric-analyzer');

async function createUltimateDashboard() {
  console.log(chalk.bold.blue('\n🚀 Creating Ultimate Intelligent Dashboard\n'));
  console.log(chalk.gray('This will:'));
  console.log(chalk.gray('  1. Discover all available data'));
  console.log(chalk.gray('  2. Analyze and categorize metrics'));
  console.log(chalk.gray('  3. Detect correlations and patterns'));
  console.log(chalk.gray('  4. Build comprehensive dashboard'));
  console.log(chalk.gray('  5. Generate dynamic metrics catalog\n'));
  
  const config = {
    accountId: process.env.ACC || process.env.NEW_RELIC_ACCOUNT_ID,
    apiKey: process.env.UKEY || process.env.NEW_RELIC_API_KEY,
    enableAnomalyDetection: true,
    enableCorrelations: true,
    enablePredictions: true
  };
  
  if (!config.accountId || !config.apiKey) {
    console.error(chalk.red('Missing account ID or API key'));
    process.exit(1);
  }
  
  console.log(chalk.gray(`Account: ${config.accountId}`));
  
  const client = new NerdGraphClient({
    apiKey: config.apiKey,
    region: 'US'
  });
  
  const spinner = ora('Starting discovery...').start();
  
  try {
    // Phase 1: Comprehensive Discovery
    spinner.text = 'Discovering all available data sources...';
    
    // Discover event types
    const eventTypeQuery = `
      SELECT count(*) 
      FROM KafkaBrokerSample, KafkaTopicSample, KafkaConsumerSample,
           KafkaProducerSample, KafkaOffsetSample, KafkaConnectSample,
           SystemSample, NetworkSample, StorageSample, ProcessSample,
           ContainerSample, LoadBalancerSample, InfrastructureEvent,
           Transaction, TransactionError, PageView, SyntheticCheck,
           NetworkSample, Log
      FACET eventType()
      SINCE 1 hour ago
      LIMIT MAX
    `;
    
    const eventTypeResult = await client.nrql(config.accountId, eventTypeQuery);
    const discoveredEventTypes = [];
    
    if (eventTypeResult?.results) {
      for (const result of eventTypeResult.results) {
        const eventTypeName = result.facet[0];
        const count = result.count;
        
        if (count > 0 && eventTypeName.length > 1) { // Skip single letter event types
          spinner.text = `Analyzing ${eventTypeName} (${count} events)...`;
          
          // Get detailed info for each event type
          try {
            // Get attributes
            const attrQuery = `
              SELECT keyset() 
              FROM ${eventTypeName} 
              SINCE 1 hour ago 
              LIMIT 1
            `;
            
            const attrResult = await client.nrql(config.accountId, attrQuery);
            const attributes = attrResult?.results?.[0]?.['keyset()'] || [];
            
            // Get sample for type detection
            const sampleQuery = `
              SELECT * 
              FROM ${eventTypeName} 
              LIMIT 1 
              SINCE 1 hour ago
            `;
            
            const sampleResult = await client.nrql(config.accountId, sampleQuery);
            const sample = sampleResult?.results?.[0] || {};
            
            // Build typed attributes
            const typedAttributes = attributes
              .filter(attr => !['timestamp', 'eventType', 'entity.guid', 'entity.name'].includes(attr))
              .map(attr => ({
                name: attr,
                type: typeof sample[attr],
                sampleValue: sample[attr]
              }));
            
            if (typedAttributes.length > 0) {
              discoveredEventTypes.push({
                name: eventTypeName,
                count: count,
                volume: count,
                attributes: typedAttributes
              });
            }
          } catch (error) {
            // Skip if error analyzing this event type
          }
        }
      }
    }
    
    spinner.succeed(`Discovered ${discoveredEventTypes.length} event types`);
    
    // Phase 2: Discover Metrics
    spinner.start('Discovering all metrics...');
    
    const metricsQuery = `
      SELECT uniques(metricName, 1000) 
      FROM Metric 
      SINCE 1 hour ago
    `;
    
    const metricsResult = await client.nrql(config.accountId, metricsQuery);
    const allMetrics = metricsResult?.results?.[0]?.['uniques.metricName'] || [];
    
    // Categorize metrics by domain
    const kafkaMetrics = allMetrics.filter(m => 
      m.toLowerCase().includes('kafka') || 
      m.toLowerCase().includes('broker') ||
      m.toLowerCase().includes('topic') ||
      m.toLowerCase().includes('consumer') ||
      m.toLowerCase().includes('producer')
    );
    
    const systemMetrics = allMetrics.filter(m => 
      m.toLowerCase().includes('system') ||
      m.toLowerCase().includes('cpu') ||
      m.toLowerCase().includes('memory') ||
      m.toLowerCase().includes('disk') ||
      m.toLowerCase().includes('network')
    );
    
    const appMetrics = allMetrics.filter(m => 
      !kafkaMetrics.includes(m) && !systemMetrics.includes(m)
    );
    
    spinner.succeed(`Discovered ${allMetrics.length} total metrics`);
    
    console.log(chalk.white('\n📊 Discovery Summary:'));
    console.log(chalk.gray(`  • Event Types: ${discoveredEventTypes.length}`));
    console.log(chalk.gray(`  • Total Metrics: ${allMetrics.length}`));
    console.log(chalk.gray(`    - Kafka: ${kafkaMetrics.length}`));
    console.log(chalk.gray(`    - System: ${systemMetrics.length}`));
    console.log(chalk.gray(`    - Application: ${appMetrics.length}`));
    
    // Display top event types
    console.log(chalk.white('\n📊 Top Event Types:'));
    discoveredEventTypes
      .sort((a, b) => b.count - a.count)
      .slice(0, 10)
      .forEach(et => {
        console.log(chalk.gray(`  • ${et.name}: ${et.count.toLocaleString()} events, ${et.attributes.length} attributes`));
      });
    
    // Phase 3: Build Discovery Results
    const discoveryResults = {
      timestamp: new Date().toISOString(),
      accountId: config.accountId,
      eventTypes: discoveredEventTypes,
      metrics: allMetrics.map(name => ({
        name,
        type: 'metric',
        unit: guessMetricUnit(name)
      })),
      relationships: detectRelationships(discoveredEventTypes)
    };
    
    // Save discovery results
    const discoveryFile = path.join(__dirname, `ultimate-discovery-${Date.now()}.json`);
    fs.writeFileSync(discoveryFile, JSON.stringify(discoveryResults, null, 2));
    console.log(chalk.gray(`\n💾 Discovery results saved to: ${discoveryFile}`));
    
    // Phase 4: Build Ultimate Dashboard
    console.log(chalk.yellow('\n🧠 Building Ultimate Intelligent Dashboard...\n'));
    
    const builder = new IntelligentDashboardBuilder(config);
    const analyzer = new AdvancedMetricAnalyzer(config);
    
    // Perform advanced analysis
    spinner.start('Performing advanced metric analysis...');
    const advancedAnalysis = await analyzer.analyzeMetrics(discoveryResults);
    spinner.succeed('Advanced analysis completed');
    
    console.log(chalk.white('\n📊 Advanced Analysis Results:'));
    if (advancedAnalysis.patterns) {
      console.log(chalk.gray(`  • Patterns detected: ${Object.keys(advancedAnalysis.patterns).length}`));
    }
    if (advancedAnalysis.anomalies) {
      console.log(chalk.gray(`  • Anomalies found: ${advancedAnalysis.anomalies.length}`));
    }
    if (advancedAnalysis.predictions) {
      console.log(chalk.gray(`  • Predictions generated: ${Object.keys(advancedAnalysis.predictions).length}`));
    }
    
    // Build dashboard with all features
    spinner.start('Building ultimate dashboard...');
    const dashboardResult = await builder.buildDashboards(discoveryResults);
    spinner.succeed('Dashboard built successfully');
    
    // Display results
    console.log(chalk.bold.green('\n✅ Ultimate Dashboard Created!\n'));
    
    // Show categorization
    console.log(chalk.white('📊 Metric Categorization:'));
    let totalCategorized = 0;
    const categoryBreakdown = {};
    
    for (const [category, metrics] of Object.entries(dashboardResult.analysis.categories)) {
      if (metrics.length > 0) {
        console.log(chalk.gray(`  • ${builder.getCategoryIcon(category)} ${builder.formatCategoryName(category)}: ${metrics.length} metrics`));
        totalCategorized += metrics.length;
        categoryBreakdown[category] = metrics.length;
      }
    }
    console.log(chalk.gray(`  • Total categorized: ${totalCategorized} metrics`));
    
    // Show golden signals
    console.log(chalk.white('\n🚦 Golden Signals Mapping:'));
    for (const [signal, metrics] of Object.entries(dashboardResult.analysis.goldenSignals)) {
      if (metrics.length > 0) {
        console.log(chalk.gray(`  • ${signal}: ${metrics.length} metrics`));
      }
    }
    
    // Show correlations
    if (dashboardResult.correlations.strong.length > 0) {
      console.log(chalk.white('\n🔗 Detected Correlations:'));
      dashboardResult.correlations.strong.slice(0, 10).forEach(corr => {
        console.log(chalk.gray(`  • ${corr.metric1} ↔ ${corr.metric2} (${corr.type})`));
      });
      if (dashboardResult.correlations.strong.length > 10) {
        console.log(chalk.gray(`  ... and ${dashboardResult.correlations.strong.length - 10} more`));
      }
    }
    
    // Show insights
    if (dashboardResult.insights.length > 0) {
      console.log(chalk.white('\n💡 Intelligent Insights:'));
      dashboardResult.insights.forEach(insight => {
        const icon = insight.severity === 'high' ? '🔴' : 
                    insight.severity === 'medium' ? '🟡' : '🟢';
        console.log(chalk.gray(`  ${icon} [${insight.severity}] ${insight.message}`));
      });
    }
    
    // Dashboard details
    console.log(chalk.white('\n📈 Dashboard Details:'));
    console.log(chalk.gray(`  • Name: ${dashboardResult.dashboard.name}`));
    console.log(chalk.gray(`  • GUID: ${dashboardResult.dashboard.guid}`));
    console.log(chalk.gray(`  • URL: ${dashboardResult.dashboard.url}`));
    
    // Verify features
    console.log(chalk.white('\n✨ Features Included:'));
    console.log(chalk.gray('  ✅ Intelligent metric categorization'));
    console.log(chalk.gray('  ✅ Dynamic metrics catalog page'));
    console.log(chalk.gray('  ✅ Golden signals dashboard'));
    console.log(chalk.gray('  ✅ Correlation detection'));
    console.log(chalk.gray('  ✅ Anomaly detection'));
    console.log(chalk.gray('  ✅ Predictive insights'));
    console.log(chalk.gray('  ✅ Optimal visualization selection'));
    console.log(chalk.gray('  ✅ Advanced metric analysis'));
    
    // Save complete results
    const outputFile = path.join(__dirname, `ultimate-dashboard-${Date.now()}.json`);
    fs.writeFileSync(outputFile, JSON.stringify({
      config: { accountId: config.accountId },
      discovery: {
        eventTypesCount: discoveredEventTypes.length,
        metricsCount: allMetrics.length,
        attributesCount: discoveredEventTypes.reduce((sum, et) => sum + et.attributes.length, 0)
      },
      categorization: categoryBreakdown,
      analysis: dashboardResult.analysis,
      correlations: dashboardResult.correlations,
      insights: dashboardResult.insights,
      dashboard: dashboardResult.dashboard,
      advancedAnalysis: advancedAnalysis
    }, null, 2));
    
    console.log(chalk.gray(`\n💾 Complete results saved to: ${outputFile}`));
    
    // Generate summary report
    console.log(chalk.bold.cyan('\n📋 Ultimate Dashboard Summary:\n'));
    console.log(chalk.white('The ultimate dashboard includes:'));
    console.log(chalk.gray(`  • ${discoveredEventTypes.length} event types analyzed`));
    console.log(chalk.gray(`  • ${allMetrics.length} metrics discovered`));
    console.log(chalk.gray(`  • ${totalCategorized} metrics intelligently categorized`));
    console.log(chalk.gray(`  • ${dashboardResult.correlations.strong.length} correlations detected`));
    console.log(chalk.gray(`  • ${dashboardResult.insights.length} insights generated`));
    console.log(chalk.gray(`  • Dynamic catalog with all metrics`));
    console.log(chalk.gray(`  • Optimal visualizations for each category`));
    
    console.log(chalk.bold.green('\n🎉 Your Ultimate Intelligent Dashboard is ready!\n'));
    
  } catch (error) {
    spinner.fail('Dashboard creation failed');
    console.error(chalk.red('\n❌ Error:'), error.message);
    
    if (error.stack) {
      console.error(chalk.gray('\nStack trace:'));
      console.error(chalk.gray(error.stack));
    }
    
    // Provide troubleshooting
    console.log(chalk.yellow('\n🔧 Troubleshooting:'));
    if (error.message.includes('permission')) {
      console.log(chalk.gray('  • Verify API key has necessary permissions'));
    } else if (error.message.includes('timeout')) {
      console.log(chalk.gray('  • Discovery may be taking too long, try with fewer event types'));
    } else if (error.message.includes('API')) {
      console.log(chalk.gray('  • Dashboard API may have issues, configuration was saved'));
    }
    
    process.exit(1);
  }
}

function guessMetricUnit(metricName) {
  const name = metricName.toLowerCase();
  
  if (name.includes('persecond') || name.includes('rate')) return 'per_second';
  if (name.includes('percent') || name.includes('percentage')) return 'percent';
  if (name.includes('bytes')) return 'bytes';
  if (name.includes('milliseconds') || name.includes('ms')) return 'milliseconds';
  if (name.includes('seconds') || name.includes('sec')) return 'seconds';
  if (name.includes('count') || name.includes('total')) return 'count';
  if (name.includes('lag')) return 'count';
  if (name.includes('size')) return 'bytes';
  if (name.includes('duration')) return 'milliseconds';
  
  return 'unknown';
}

function detectRelationships(eventTypes) {
  const relationships = [];
  
  // Detect common relationships
  const hasKafka = eventTypes.find(et => et.name.includes('Kafka'));
  const hasSystem = eventTypes.find(et => et.name === 'SystemSample');
  const hasContainer = eventTypes.find(et => et.name === 'ContainerSample');
  const hasTransaction = eventTypes.find(et => et.name === 'Transaction');
  
  if (hasKafka && hasSystem) {
    relationships.push({
      from: hasKafka.name,
      to: 'SystemSample',
      type: 'runs_on'
    });
  }
  
  if (hasContainer && hasSystem) {
    relationships.push({
      from: 'ContainerSample',
      to: 'SystemSample',
      type: 'runs_on'
    });
  }
  
  if (hasTransaction && hasKafka) {
    relationships.push({
      from: 'Transaction',
      to: hasKafka.name,
      type: 'uses'
    });
  }
  
  return relationships;
}

// Run the ultimate dashboard creation
createUltimateDashboard().catch(console.error);