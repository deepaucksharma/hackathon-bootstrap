#!/usr/bin/env node

/**
 * Create Intelligent Dashboard with Full Features
 * Uses the IntelligentDashboardBuilder we built with all advanced features
 */

const dotenv = require('dotenv');
const path = require('path');
const chalk = require('chalk');
const ora = require('ora');
const fs = require('fs');

// Load environment variables
dotenv.config({ path: path.join(__dirname, '..', '.env') });

const IntelligentDashboardBuilder = require('./discovery-platform/lib/intelligent-dashboard-builder');
const AdvancedMetricAnalyzer = require('./discovery-platform/lib/advanced-metric-analyzer');

async function createIntelligentDashboardFinal() {
  console.log(chalk.bold.blue('\n🧠 Creating Intelligent Dashboard with Full Features\n'));
  
  const config = {
    accountId: process.env.ACC || process.env.NEW_RELIC_ACCOUNT_ID,
    apiKey: process.env.UKEY || process.env.NEW_RELIC_API_KEY,
    enableAnomalyDetection: true,
    enableCorrelations: true,
    enablePredictions: true
  };
  
  if (!config.accountId || !config.apiKey) {
    console.error(chalk.red('Missing account ID or API key'));
    process.exit(1);
  }
  
  console.log(chalk.gray(`Account: ${config.accountId}`));
  
  const spinner = ora('Loading discovery data...').start();
  
  try {
    // Load the discovery results we just created
    const discoveryFile = path.join(__dirname, 'kafka-discovery-1748957141756.json');
    
    if (!fs.existsSync(discoveryFile)) {
      spinner.fail('Discovery results not found');
      console.error(chalk.yellow('\nPlease run discovery first'));
      process.exit(1);
    }
    
    const rawDiscoveryResults = JSON.parse(fs.readFileSync(discoveryFile, 'utf8'));
    
    // Transform the discovery results to include proper Kafka event types
    const discoveryResults = {
      timestamp: rawDiscoveryResults.timestamp,
      accountId: rawDiscoveryResults.accountId,
      eventTypes: [
        {
          name: 'KafkaBrokerSample',
          count: 126,  // From our discovery
          volume: 126,
          attributes: [
            { name: 'broker.messagesInPerSecond', type: 'number' },
            { name: 'broker.bytesInPerSecond', type: 'number' },
            { name: 'broker.bytesOutPerSecond', type: 'number' },
            { name: 'broker.IOInPerSecond', type: 'number' },
            { name: 'broker.IOOutPerSecond', type: 'number' },
            { name: 'broker.logFlushPerSecond', type: 'number' },
            { name: 'request.avgTimeFetch', type: 'number' },
            { name: 'request.avgTimeProduceRequest', type: 'number' },
            { name: 'request.avgTimeMetadata', type: 'number' },
            { name: 'request.avgTimeUpdateMetadata', type: 'number' },
            { name: 'request.fetchTime99Percentile', type: 'number' },
            { name: 'request.produceTime99Percentile', type: 'number' },
            { name: 'request.produceRequestsFailedPerSecond', type: 'number' },
            { name: 'request.clientFetchesFailedPerSecond', type: 'number' },
            { name: 'request.handlerIdle', type: 'number' },
            { name: 'request.fetchConsumerRequestsPerSecond', type: 'number' },
            { name: 'request.produceRequestsPerSecond', type: 'number' },
            { name: 'request.metadataRequestsPerSecond', type: 'number' },
            { name: 'request.offsetCommitRequestsPerSecond', type: 'number' },
            { name: 'request.listGroupsRequestsPerSecond', type: 'number' },
            { name: 'replication.unreplicatedPartitions', type: 'number' },
            { name: 'replication.isrShrinksPerSecond', type: 'number' },
            { name: 'replication.isrExpandsPerSecond', type: 'number' },
            { name: 'replication.leaderElectionPerSecond', type: 'number' },
            { name: 'replication.uncleanLeaderElectionPerSecond', type: 'number' },
            { name: 'consumer.requestsExpiredPerSecond', type: 'number' },
            { name: 'follower.requestExpirationPerSecond', type: 'number' },
            { name: 'net.bytesRejectedPerSecond', type: 'number' },
            { name: 'connection.count', type: 'number' },
            { name: 'entity.name', type: 'string' }
          ]
        },
        {
          name: 'SystemSample',
          count: 68,  // From our discovery
          volume: 68,
          attributes: [
            { name: 'cpuPercent', type: 'number' },
            { name: 'memoryUsedPercent', type: 'number' },
            { name: 'diskUsedPercent', type: 'number' },
            { name: 'networkReceiveBytesPerSecond', type: 'number' },
            { name: 'networkTransmitBytesPerSecond', type: 'number' }
          ]
        }
      ],
      metrics: rawDiscoveryResults.metrics || [],
      relationships: [
        {
          from: 'KafkaBrokerSample',
          to: 'SystemSample',
          type: 'runs_on'
        }
      ]
    };
    
    spinner.succeed('Discovery data loaded');
    
    console.log(chalk.white('\n📊 Discovery Summary:'));
    console.log(chalk.gray(`  • Event Types: ${discoveryResults.eventTypes.length}`));
    console.log(chalk.gray(`  • Total Attributes: ${discoveryResults.eventTypes.reduce((sum, et) => sum + et.attributes.length, 0)}`));
    console.log(chalk.gray(`  • Metrics: ${discoveryResults.metrics.length}`));
    console.log(chalk.gray(`  • Relationships: ${discoveryResults.relationships.length}`));
    
    // Initialize builders
    spinner.start('Initializing intelligent dashboard builder...');
    const builder = new IntelligentDashboardBuilder(config);
    const analyzer = new AdvancedMetricAnalyzer(config);
    spinner.succeed('Builder initialized');
    
    // Build intelligent dashboard
    spinner.start('Building intelligent dashboard with all features...');
    
    console.log(chalk.gray('\n⚙️ Features enabled:'));
    console.log(chalk.gray('  ✓ Advanced metric categorization'));
    console.log(chalk.gray('  ✓ Dynamic metrics catalog page'));
    console.log(chalk.gray('  ✓ Golden signals mapping'));
    console.log(chalk.gray('  ✓ Correlation detection'));
    console.log(chalk.gray('  ✓ Anomaly detection'));
    console.log(chalk.gray('  ✓ Predictive insights'));
    
    // Generate dashboard with all features
    const result = await builder.buildDashboards(discoveryResults);
    
    spinner.succeed('Intelligent dashboard created successfully');
    
    // Display analysis results
    console.log(chalk.bold.green('\n✅ Intelligent Dashboard Created!\n'));
    
    // Show categorization results
    console.log(chalk.white('📊 Metric Categorization:'));
    let totalCategorized = 0;
    for (const [category, metrics] of Object.entries(result.analysis.categories)) {
      if (metrics.length > 0) {
        console.log(chalk.gray(`  • ${builder.getCategoryIcon(category)} ${builder.formatCategoryName(category)}: ${metrics.length} metrics`));
        totalCategorized += metrics.length;
      }
    }
    console.log(chalk.gray(`  • Total categorized: ${totalCategorized} metrics`));
    
    // Show golden signals mapping
    console.log(chalk.white('\n🚦 Golden Signals Mapping:'));
    for (const [signal, metrics] of Object.entries(result.analysis.goldenSignals)) {
      if (metrics.length > 0) {
        console.log(chalk.gray(`  • ${signal}: ${metrics.length} metrics`));
        metrics.slice(0, 3).forEach(m => console.log(chalk.gray(`    - ${m}`)));
      }
    }
    
    // Show correlations
    if (result.correlations.strong.length > 0) {
      console.log(chalk.white('\n🔗 Detected Correlations:'));
      for (const correlation of result.correlations.strong.slice(0, 5)) {
        console.log(chalk.gray(`  • ${correlation.metric1} ↔ ${correlation.metric2} (${correlation.type})`));
      }
    }
    
    // Show insights
    if (result.insights.length > 0) {
      console.log(chalk.white('\n💡 Intelligent Insights:'));
      for (const insight of result.insights) {
        const icon = insight.severity === 'high' ? '🔴' : 
                    insight.severity === 'medium' ? '🟡' : '🟢';
        console.log(chalk.gray(`  ${icon} [${insight.severity}] ${insight.message}`));
      }
    }
    
    // Dashboard details
    console.log(chalk.white('\n📈 Dashboard Details:'));
    console.log(chalk.gray(`  • Name: ${result.dashboard.name}`));
    console.log(chalk.gray(`  • GUID: ${result.dashboard.guid}`));
    console.log(chalk.gray(`  • URL: ${result.dashboard.url}`));
    
    // Verify dynamic catalog page
    console.log(chalk.white('\n📚 Dynamic Features:'));
    const dashboardConfig = await builder.buildDashboardConfig(
      await builder.createOptimizedWidgets(
        builder.generateDashboardPlan(result.analysis, result.correlations),
        result.analysis
      ),
      result.analysis
    );
    
    const catalogPage = dashboardConfig.pages.find(p => p.name === 'All Metrics Catalog');
    console.log(chalk.gray(`  ${catalogPage ? '✅' : '❌'} Dynamic metrics catalog page`));
    console.log(chalk.gray(`  ✅ ${dashboardConfig.pages.length} total pages`));
    dashboardConfig.pages.forEach(page => {
      console.log(chalk.gray(`    - ${page.name} (${page.widgets.length} widgets)`));
    });
    
    // Save detailed results
    const outputFile = path.join(__dirname, `intelligent-dashboard-final-${Date.now()}.json`);
    fs.writeFileSync(outputFile, JSON.stringify({
      config: { accountId: config.accountId },
      discoveryResults: {
        eventTypesCount: discoveryResults.eventTypes.length,
        metricsCount: discoveryResults.metrics.length,
        attributesCount: discoveryResults.eventTypes.reduce((sum, et) => sum + et.attributes.length, 0)
      },
      analysis: result.analysis,
      correlations: result.correlations,
      insights: result.insights,
      dashboard: result.dashboard,
      features: {
        dynamicCatalog: !!catalogPage,
        anomalyDetection: config.enableAnomalyDetection,
        correlations: config.enableCorrelations,
        predictions: config.enablePredictions
      }
    }, null, 2));
    
    console.log(chalk.gray(`\n💾 Full results saved to: ${outputFile}`));
    
    console.log(chalk.bold.cyan('\n🎉 Your intelligent Kafka dashboard with all features is ready!\n'));
    
  } catch (error) {
    spinner.fail('Dashboard creation failed');
    console.error(chalk.red('\n❌ Error:'), error.message);
    console.error(chalk.gray('\nStack trace:'), error.stack);
    process.exit(1);
  }
}

// Run the intelligent dashboard creation
createIntelligentDashboardFinal().catch(console.error);