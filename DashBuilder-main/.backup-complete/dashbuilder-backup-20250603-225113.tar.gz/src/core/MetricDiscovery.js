/**
 * MetricDiscovery - Unified metric discovery engine
 * 
 * Consolidates all discovery implementations into a single, efficient class
 */

const nerdgraph = require('../utils/nerdgraph');
const logger = require('../utils/logger');
const { RateLimiter } = require('../utils/rateLimiter');
const { Cache } = require('../utils/cache');

class MetricDiscovery {
  constructor(config) {
    this.config = config;
    this.client = new nerdgraph.NerdGraphClient(config);
    this.rateLimiter = new RateLimiter({ maxConcurrent: 10, minTime: 200 });
    this.cache = new Cache({ ttl: 300000 }); // 5 minute cache
    
    // Discovery strategies
    this.strategies = {
      comprehensive: this.comprehensiveDiscovery.bind(this),
      intelligent: this.intelligentDiscovery.bind(this),
      pattern: this.patternBasedDiscovery.bind(this),
      quick: this.quickDiscovery.bind(this)
    };
  }

  /**
   * Main discovery method
   */
  async discover(options = {}) {
    const strategy = options.strategy || 'intelligent';
    const cacheKey = this.getCacheKey(options);
    
    // Check cache first
    if (options.useCache !== false) {
      const cached = this.cache.get(cacheKey);
      if (cached) {
        logger.info('Using cached discovery results');
        return cached;
      }
    }
    
    logger.info(`Starting metric discovery with ${strategy} strategy`);
    
    try {
      const results = await this.strategies[strategy](options);
      
      // Post-process and enrich results
      const enriched = await this.enrichResults(results, options);
      
      // Cache results
      if (options.useCache !== false) {
        this.cache.set(cacheKey, enriched);
      }
      
      return enriched;
      
    } catch (error) {
      logger.error('Metric discovery failed', error);
      throw error;
    }
  }

  /**
   * Comprehensive discovery - finds all available metrics
   */
  async comprehensiveDiscovery(options) {
    const results = {
      eventTypes: [],
      metrics: {},
      totalMetrics: 0,
      discoveryTime: new Date().toISOString()
    };
    
    // Step 1: Get all event types
    const eventTypes = await this.getEventTypes();
    
    // Step 2: Get metrics for each event type
    const promises = eventTypes.map(eventType => 
      this.rateLimiter.schedule(() => this.getEventTypeMetrics(eventType))
    );
    
    const eventMetrics = await Promise.all(promises);
    
    // Step 3: Organize results
    eventTypes.forEach((eventType, index) => {
      const metrics = eventMetrics[index];
      if (metrics && metrics.length > 0) {
        results.eventTypes.push(eventType);
        results.metrics[eventType] = metrics;
        results.totalMetrics += metrics.length;
      }
    });
    
    return results;
  }

  /**
   * Intelligent discovery - uses patterns and heuristics
   */
  async intelligentDiscovery(options) {
    // Start with key event types
    const priorityEventTypes = await this.identifyPriorityEventTypes(options);
    
    const results = {
      eventTypes: [],
      metrics: {},
      totalMetrics: 0,
      categories: {},
      recommendations: []
    };
    
    // Discover metrics for priority event types
    for (const eventType of priorityEventTypes) {
      const metrics = await this.getEventTypeMetrics(eventType);
      
      if (metrics && metrics.length > 0) {
        results.eventTypes.push(eventType);
        results.metrics[eventType] = metrics;
        results.totalMetrics += metrics.length;
        
        // Categorize metrics
        this.categorizeMetrics(eventType, metrics, results.categories);
      }
    }
    
    // Generate recommendations
    results.recommendations = this.generateRecommendations(results);
    
    return results;
  }

  /**
   * Pattern-based discovery
   */
  async patternBasedDiscovery(options) {
    const patterns = options.patterns || this.getDefaultPatterns();
    const results = {
      eventTypes: [],
      metrics: {},
      totalMetrics: 0,
      matchedPatterns: {}
    };
    
    // Get all event types
    const eventTypes = await this.getEventTypes();
    
    // Search for metrics matching patterns
    for (const eventType of eventTypes) {
      const metrics = await this.getEventTypeMetrics(eventType);
      const matchedMetrics = [];
      
      for (const metric of metrics) {
        for (const [patternName, pattern] of Object.entries(patterns)) {
          if (pattern.test(metric.name)) {
            matchedMetrics.push(metric);
            
            if (!results.matchedPatterns[patternName]) {
              results.matchedPatterns[patternName] = [];
            }
            results.matchedPatterns[patternName].push({
              eventType,
              metric: metric.name
            });
            break;
          }
        }
      }
      
      if (matchedMetrics.length > 0) {
        results.eventTypes.push(eventType);
        results.metrics[eventType] = matchedMetrics;
        results.totalMetrics += matchedMetrics.length;
      }
    }
    
    return results;
  }

  /**
   * Quick discovery - limited but fast
   */
  async quickDiscovery(options) {
    const limit = options.limit || 5;
    const commonEventTypes = [
      'SystemSample',
      'ProcessSample',
      'NetworkSample',
      'StorageSample',
      'Transaction'
    ];
    
    const results = {
      eventTypes: [],
      metrics: {},
      totalMetrics: 0
    };
    
    // Get metrics for common event types only
    const eventTypesToCheck = commonEventTypes.slice(0, limit);
    
    for (const eventType of eventTypesToCheck) {
      try {
        const metrics = await this.getEventTypeMetrics(eventType);
        if (metrics && metrics.length > 0) {
          results.eventTypes.push(eventType);
          results.metrics[eventType] = metrics.slice(0, 10); // Limit metrics per type
          results.totalMetrics += results.metrics[eventType].length;
        }
      } catch (error) {
        // Skip if event type doesn't exist
        logger.debug(`Event type ${eventType} not found`);
      }
    }
    
    return results;
  }

  /**
   * Get all available event types
   */
  async getEventTypes() {
    const query = `
      {
        actor {
          account(id: ${this.config.accountId}) {
            nrql(query: "SHOW EVENT TYPES") {
              results
            }
          }
        }
      }
    `;
    
    const response = await this.client.query(query);
    const results = response?.actor?.account?.nrql?.results || [];
    
    return results.map(r => r.eventType).filter(Boolean);
  }

  /**
   * Get metrics for a specific event type
   */
  async getEventTypeMetrics(eventType) {
    const query = `
      {
        actor {
          account(id: ${this.config.accountId}) {
            nrql(query: "SELECT keyset() FROM ${eventType} LIMIT 1") {
              results
            }
          }
        }
      }
    `;
    
    try {
      const response = await this.client.query(query);
      const results = response?.actor?.account?.nrql?.results || [];
      
      if (results.length > 0 && results[0].allKeys) {
        return results[0].allKeys.map(key => ({
          name: key,
          type: this.inferMetricType(key),
          eventType
        }));
      }
    } catch (error) {
      logger.debug(`Failed to get metrics for ${eventType}`, error);
    }
    
    return [];
  }

  /**
   * Identify priority event types based on context
   */
  async identifyPriorityEventTypes(options) {
    // Check for domain-specific event types
    if (options.domain === 'kafka' || options.template === 'kafka') {
      return [
        'KafkaBrokerSample',
        'KafkaTopicSample', 
        'KafkaConsumerSample',
        'KafkaProducerSample',
        'QueueSample',
        'Metric' // For custom metrics
      ];
    }
    
    // Default priority event types
    const query = `
      {
        actor {
          account(id: ${this.config.accountId}) {
            nrql(query: "SELECT count(*) FROM Log, Metric, SystemSample, ProcessSample, NetworkSample, Transaction, PageView FACET eventType() SINCE 1 hour ago") {
              results
            }
          }
        }
      }
    `;
    
    const response = await this.client.query(query);
    const results = response?.actor?.account?.nrql?.results || [];
    
    // Sort by count and return top event types
    return results
      .sort((a, b) => b.count - a.count)
      .slice(0, 10)
      .map(r => r.facet)
      .filter(Boolean);
  }

  /**
   * Categorize metrics
   */
  categorizeMetrics(eventType, metrics, categories) {
    const patterns = {
      performance: /latency|duration|time|response|throughput|rate|ops/i,
      errors: /error|fail|exception|timeout|reject/i,
      capacity: /count|total|size|queue|backlog|pending/i,
      utilization: /percent|usage|utilization|cpu|memory|disk/i,
      business: /revenue|transaction|user|session|conversion/i
    };
    
    for (const metric of metrics) {
      let categorized = false;
      
      for (const [category, pattern] of Object.entries(patterns)) {
        if (pattern.test(metric.name)) {
          if (!categories[category]) {
            categories[category] = [];
          }
          categories[category].push({
            eventType,
            name: metric.name,
            type: metric.type
          });
          categorized = true;
          break;
        }
      }
      
      if (!categorized) {
        if (!categories.other) {
          categories.other = [];
        }
        categories.other.push({
          eventType,
          name: metric.name,
          type: metric.type
        });
      }
    }
  }

  /**
   * Generate recommendations based on discovered metrics
   */
  generateRecommendations(results) {
    const recommendations = [];
    
    // Check for key metrics
    if (results.categories.errors && results.categories.errors.length > 0) {
      recommendations.push({
        type: 'alert',
        message: 'Error metrics detected - consider setting up alerts',
        metrics: results.categories.errors.slice(0, 3)
      });
    }
    
    if (results.categories.performance && results.categories.performance.length > 0) {
      recommendations.push({
        type: 'sla',
        message: 'Performance metrics available for SLA monitoring',
        metrics: results.categories.performance.slice(0, 3)
      });
    }
    
    // Check for correlated metrics
    if (results.categories.utilization && results.categories.capacity) {
      recommendations.push({
        type: 'correlation',
        message: 'Utilization and capacity metrics can be correlated',
        suggestion: 'Create combined views showing resource usage vs limits'
      });
    }
    
    return recommendations;
  }

  /**
   * Infer metric type from name
   */
  inferMetricType(metricName) {
    const name = metricName.toLowerCase();
    
    if (name.includes('count') || name.includes('total')) return 'count';
    if (name.includes('percent') || name.includes('ratio')) return 'percentage';
    if (name.includes('bytes') || name.includes('size')) return 'bytes';
    if (name.includes('time') || name.includes('duration')) return 'duration';
    if (name.includes('rate') || name.includes('persec')) return 'rate';
    
    return 'gauge';
  }

  /**
   * Get default patterns for pattern-based discovery
   */
  getDefaultPatterns() {
    return {
      kafka: /kafka|topic|partition|broker|consumer|producer|offset|lag/i,
      performance: /latency|duration|response|throughput|rate/i,
      errors: /error|fail|exception|timeout/i,
      infrastructure: /cpu|memory|disk|network|io/i,
      business: /transaction|revenue|user|session/i
    };
  }

  /**
   * Enrich discovery results with additional metadata
   */
  async enrichResults(results, options) {
    // Add summary statistics
    results.summary = {
      totalEventTypes: results.eventTypes.length,
      totalMetrics: results.totalMetrics,
      topEventTypes: this.getTopEventTypes(results),
      metricTypes: this.summarizeMetricTypes(results)
    };
    
    // Add quality scores if intelligent mode
    if (options.strategy === 'intelligent' && results.categories) {
      results.qualityScores = this.calculateQualityScores(results);
    }
    
    return results;
  }

  /**
   * Get top event types by metric count
   */
  getTopEventTypes(results) {
    return Object.entries(results.metrics)
      .map(([eventType, metrics]) => ({
        eventType,
        metricCount: metrics.length
      }))
      .sort((a, b) => b.metricCount - a.metricCount)
      .slice(0, 5);
  }

  /**
   * Summarize metric types
   */
  summarizeMetricTypes(results) {
    const types = {};
    
    for (const metrics of Object.values(results.metrics)) {
      for (const metric of metrics) {
        types[metric.type] = (types[metric.type] || 0) + 1;
      }
    }
    
    return types;
  }

  /**
   * Calculate quality scores for categories
   */
  calculateQualityScores(results) {
    const scores = {};
    
    for (const [category, metrics] of Object.entries(results.categories || {})) {
      scores[category] = {
        count: metrics.length,
        quality: this.assessCategoryQuality(category, metrics),
        priority: this.getCategoryPriority(category)
      };
    }
    
    return scores;
  }

  /**
   * Assess quality of metrics in a category
   */
  assessCategoryQuality(category, metrics) {
    let score = 0;
    
    // More metrics = better coverage
    score += Math.min(metrics.length / 10, 1) * 0.3;
    
    // Variety of event types = better
    const eventTypes = new Set(metrics.map(m => m.eventType));
    score += Math.min(eventTypes.size / 5, 1) * 0.3;
    
    // Category-specific quality checks
    if (category === 'errors' || category === 'performance') {
      score += 0.4; // High-value categories
    } else {
      score += 0.2;
    }
    
    return score;
  }

  /**
   * Get category priority
   */
  getCategoryPriority(category) {
    const priorities = {
      errors: 1,
      performance: 2,
      business: 3,
      capacity: 4,
      utilization: 5,
      other: 6
    };
    
    return priorities[category] || 999;
  }

  /**
   * Generate cache key
   */
  getCacheKey(options) {
    return `discovery:${this.config.accountId}:${options.strategy || 'intelligent'}:${JSON.stringify(options.patterns || {})}`;
  }
}

module.exports = MetricDiscovery;